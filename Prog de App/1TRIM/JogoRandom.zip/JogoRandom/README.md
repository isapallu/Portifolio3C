# JogoRandom
Utilizando a classe Random para gerar um número aleatório entre 1 e 100

5 tentativas para acertar o número gerado;

Informar se a tentativa é maior ou menor que o número gerado, e quantas tentativas restam;

Se a tentativa for igual, informar que venceu, e quantas tentativas foram utilizadas;
